#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


PROJECT_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT_FILE = PROJECT_DIR / "experiments" / "reports" / "model_comparison.csv"


def best_record(run_dir: Path) -> dict:
    path = run_dir / "metrics.jsonl"
    records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]
    if not records:
        raise ValueError(f"No metric records in {path}")
    return min(records, key=lambda item: item["validation"]["rmse"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dirs", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT_FILE)
    args = parser.parse_args()

    rows = []
    for run_dir in args.run_dirs:
        config = json.loads((run_dir / "config.json").read_text(encoding="utf-8"))
        record = best_record(run_dir)
        metrics = record["validation"]
        holdout_path = run_dir / "holdout_metrics.json"
        holdout = json.loads(holdout_path.read_text(encoding="utf-8")) if holdout_path.exists() else {}
        categorical = metrics.get("categorical", {})
        rows.append(
            {
                "model": config["model"],
                "head_variant": config.get("head_variant", "full"),
                "loss": config.get("loss", "unknown"),
                "seed": config.get("seed"),
                "run_dir": str(run_dir),
                "best_epoch": record["epoch"],
                "mae": metrics["mae"],
                "rmse": metrics["rmse"],
                "holdout_mae": holdout.get("mae"),
                "holdout_rmse": holdout.get("rmse"),
                "r2": metrics["r2"],
                "pearson": metrics["pearson"],
                "q90_csi": categorical.get("q90", {}).get("csi"),
                "q90_pod": categorical.get("q90", {}).get("pod"),
                "q90_far": categorical.get("q90", {}).get("far"),
                "q95_csi": categorical.get("q95", {}).get("csi"),
                "q95_pod": categorical.get("q95", {}).get("pod"),
                "q95_far": categorical.get("q95", {}).get("far"),
            }
        )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote comparison to {args.output}")


if __name__ == "__main__":
    main()
