# 修改文件清单

本项目保留原始入口，并提供 `_modified` 版本供本次数据划分和训练流程使用。

| 文件 | 用途 |
|---|---|
| `train_modified.py` | 支持独立训练集/验证集文件；训练集和验证集不重叠检查；warmup、早停、梯度裁剪与梯度范数记录；三种核心模型默认学习率 `1e-4`；可选独立留出集；生成 TestA/TestB 预测 |
| `scripts/train_core_models_modified.sh` | 依次训练 Earthformer、PredRNN、ConvLSTM，统一初始学习率 `1e-4`、最多 100 轮、早停耐心 20，然后运行比较、出图、融合和提交格式检查 |
| `compare_runs_modified.py` | 汇总模型验证集指标；独立留出指标为可选项 |
| `ensemble_modified.py` | 基于验证集选择融合权重；有独立留出数据时才生成留出指标 |
| `report_experiments_modified.py` | 生成学习曲线、模型比较图、观测值与预测值散点图及实验报告 |
| `src/tianchi_rainfall/losses_modified.py` | 提供修改版训练脚本所用的损失函数 |
| `smoke_test_modified.py` | 检查模型前向、反向和梯度有限性；需要服务器上的 vendor 模型代码 |
| `visualize_prediction.py` | 输出单样本预测/注意力可视化 |
| `README.md` | 安装、数据路径、训练命令和输出说明 |

两份数据模式要求 `TRAIN_FILE` 与 `VALIDATION_FILE` 分别指向带标签的 NPY 输入数组；配套 targets 和 ids 文件需与 inputs 文件在同一目录。当前模式没有独立 holdout，报告会注明验证集参与了 checkpoint 与融合权重选择。

自动训练脚本需要服务器上可用的 CUDA PyTorch、项目依赖、三个 pinned vendor 模型目录，以及已准备好的训练/验证数据。此清单只记录代码和流程，不代表已在服务器完成部署或训练。
