#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
data_root="${DATA_ROOT:-/vdb/tianchi/cikm2017/data_new}"
train_file="${TRAIN_FILE:?Set TRAIN_FILE to the labeled training *_inputs.npy file}"
validation_file="${VALIDATION_FILE:?Set VALIDATION_FILE to the labeled validation *_inputs.npy file}"
test_b_file="${TEST_B_FILE:-${data_root}/CIKM2017_testB/testB_crop41_inputs.npy}"
test_a_file="${TEST_A_FILE:-${data_root}/CIKM2017_testA/testA_crop41_inputs.npy}"
answer_b="${ANSWER_B:-${data_root}/CIKM2017_testB/answer_sample.csv}"
answer_a="${ANSWER_A:-${data_root}/CIKM2017_testA/answer_sample.csv}"
vendor_root="${VENDOR_ROOT:-${project_dir}/vendor}"
output_root="${OUTPUT_ROOT:-${project_dir}/experiments}"
crop_size="${CROP_SIZE:-41}"
epochs="${EPOCHS:-100}"
early_stopping_patience="${EARLY_STOPPING_PATIENCE:-20}"
num_workers="${NUM_WORKERS:-4}"
batch_convlstm="${BATCH_SIZE_CONVLSTM:-8}"
batch_predrnn="${BATCH_SIZE_PREDRNN:-4}"
batch_earthformer="${BATCH_SIZE_EARTHFORMER:-1}"
device="${DEVICE:-cuda}"
python_bin="${PYTHON_BIN:-python}"
run_id="${RUN_ID:-$(date +%Y%m%d-%H%M%S)}"
run_root="${output_root}/${run_id}"

for path in "${train_file}" "${validation_file}" "${test_b_file}" "${test_a_file}" "${answer_b}" "${answer_a}"; do
  if [[ ! -f "${path}" ]]; then
    echo "Required input file not found: ${path}" >&2
    exit 2
  fi
done
if [[ ! -d "${vendor_root}" ]]; then
  echo "Vendor directory not found: ${vendor_root}; run scripts/bootstrap_vendor.sh first" >&2
  exit 2
fi
if [[ -e "${run_root}" ]]; then
  echo "Run output already exists: ${run_root}; set a new RUN_ID" >&2
  exit 2
fi
mkdir -p "${run_root}/reports"
cd "${project_dir}"

amp_args=()
if [[ "${device}" == "cuda" ]]; then
  amp_args+=(--amp)
fi

train_one() {
  local model="$1" batch_size="$2" learning_rate="$3" hidden_dims="$4" base_units="$5"
  local run_dir="${run_root}/${model}"
  local model_args=()
  if [[ -n "${hidden_dims}" ]]; then model_args+=(--hidden-dims "${hidden_dims}"); fi
  if [[ -n "${base_units}" ]]; then model_args+=(--earthformer-base-units "${base_units}"); fi
  "${python_bin}" train_modified.py \
    --model "${model}" \
    --train-file "${train_file}" \
    --validation-file "${validation_file}" \
    --test-file "${test_b_file}" \
    --test-a-file "${test_a_file}" \
    --vendor-root "${vendor_root}" \
    --output-dir "${run_dir}" \
    --epochs "${epochs}" \
    --early-stopping-patience "${early_stopping_patience}" \
    --warmup-epochs 3 \
    --batch-size "${batch_size}" \
    --num-workers "${num_workers}" \
    --learning-rate "${learning_rate}" \
    --crop-size "${crop_size}" \
    --seed 42 \
    --device "${device}" \
    "${amp_args[@]}" \
    "${model_args[@]}"
}

# Conservative starting settings; the run logs record LR and pre-clip gradient norms.
train_one earthformer "${batch_earthformer}" 0.0001 "" 32
train_one predrnn "${batch_predrnn}" 0.0001 "32,32" ""
train_one convlstm "${batch_convlstm}" 0.0001 "16,32" ""

"${python_bin}" compare_runs_modified.py \
  "${run_root}/convlstm" "${run_root}/predrnn" "${run_root}/earthformer" \
  --output "${run_root}/reports/model_comparison.csv"
"${python_bin}" report_experiments_modified.py \
  "${run_root}/convlstm" "${run_root}/predrnn" "${run_root}/earthformer" \
  --output-dir "${run_root}/reports"
"${python_bin}" ensemble_modified.py \
  "${run_root}/convlstm" "${run_root}/predrnn" "${run_root}/earthformer" \
  --output-dir "${run_root}/ensemble"
"${python_bin}" validate_submission.py \
  --prediction-file "${run_root}/ensemble/test_predictions.csv" \
  --answer-sample "${answer_b}" \
  --report-file "${run_root}/ensemble/submission_validation.json"
"${python_bin}" validate_submission.py \
  --prediction-file "${run_root}/ensemble/testA_predictions.csv" \
  --answer-sample "${answer_a}" \
  --report-file "${run_root}/ensemble/testA_submission_validation.json"

for model in convlstm predrnn earthformer; do
  "${python_bin}" visualize_prediction.py \
    --checkpoint "${run_root}/${model}/best.pt" \
    --data-file "${validation_file}" \
    --vendor-root "${vendor_root}" \
    --sample-index 0 \
    --device "${device}" \
    --output-file "${run_root}/reports/${model}_attention.png"
done

echo "Training, plots, comparison, and submission checks completed: ${run_root}"
